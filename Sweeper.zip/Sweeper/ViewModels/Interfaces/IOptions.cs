﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sweeper.ViewModels.Interfaces
{
    interface IOptions
    {
        bool SoundOn
        {
            get;
            set;
        }
        
    }
}
