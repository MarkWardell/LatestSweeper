﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sweeper.ViewModels
{
    public class RealDialogService : IDialogService
    {
        public void ShowAbout()
        {
            throw new NotImplementedException();
        }

        public void ShowGameResult()
        {
            throw new NotImplementedException();
        }

        public void ShowLogoptions()
        {
            throw new NotImplementedException();
        }

        public bool ShowCustomGame()
        {
            throw new NotImplementedException();
        }
    }
}
