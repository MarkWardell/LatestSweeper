﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sweeper.ViewModels
{
    public struct CustomGameStruct
    {
        int rows;
        int cols;
        int mines;
    }
}
